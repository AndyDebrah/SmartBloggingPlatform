Epic 5 — Metrics & Reporting (Quick Start)

Goal
- Expose application metrics (HTTP, JVM, datasource, Hikari) and a Prometheus scrape endpoint for dashboarding and alerting.

What was added
- Spring Boot Actuator dependency
- Micrometer Prometheus registry dependency
- `MetricsConfig` registering `TimedAspect` so `@Timed` annotations work
- `management.endpoints.web.exposure.include` enabled in `application-test.properties`

Quick validation steps
1. Build the project:

```powershell
./mvnw.cmd -DskipTests package
```

2. Start the app with the `test` profile (fixed port):

```powershell
./mvnw.cmd -DskipTests -Dspring-boot.run.arguments="--spring.profiles.active=test --server.port=8080" spring-boot:run
```

3. Confirm Prometheus endpoint is available:

```powershell
curl http://localhost:8080/actuator/prometheus | Select-String "http.server.requests"
```

4. Run a short load (wrk/hey/curl loop) against `/api/posts` and re-query the Prometheus endpoint to see updated metrics.

Next recommended steps
- Add `@Timed` to hot service methods and controllers (I can add these automatically to the top endpoints).
- Add Grafana dashboard JSON (optional) and instructions to import.
- Configure Hikari and datasource metrics (already available via Micrometer when using Hikari).


